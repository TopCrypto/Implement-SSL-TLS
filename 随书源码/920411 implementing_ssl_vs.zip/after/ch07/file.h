#ifndef FILE_H
#define FILE_H

char *load_file_into_memory( char *filename, int *buffer_length );

#endif
