#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "aes.h"
#include "hex.h"
