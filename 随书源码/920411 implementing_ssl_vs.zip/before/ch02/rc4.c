#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "rc4.h"
#include "hex.h"
