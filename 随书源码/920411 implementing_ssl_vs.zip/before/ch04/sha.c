#include <stdlib.h>
#include <string.h>
#ifdef WIN32
#include <winsock.h>
#include <windows.h>
#else
#include <arpa/inet.h>
#endif
#include "sha.h"
