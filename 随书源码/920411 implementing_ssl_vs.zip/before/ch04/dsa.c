#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sha.h"
#include "hex.h"
#include "digest.h"
#include "dsa.h"
