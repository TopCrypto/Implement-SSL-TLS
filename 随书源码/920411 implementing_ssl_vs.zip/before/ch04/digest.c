#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "digest.h"
#include "md5.h"
#include "sha.h"
